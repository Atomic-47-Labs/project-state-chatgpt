---
name: project-orchestrator
description: "The conductor of the project-* skill suite. Decides what to do next based on current state + the calendar (day of week, proximity to quarterly claim deadlines, SC meeting cadence, phase gate status, overdue milestones, annual questionnaire). Use whenever the user says 'what should I do today', 'what should I do this week', 'run the project', 'what's pending', 'what needs attention', 'morning briefing for the project', 'are there any deadlines coming up', 'what's the orchestrator saying', 'run the weekly routine', 'run the daily routine', 'kickoff the day', or any request asking the project to tell itself what to do next. Invokes other project-* skills as needed and hands decisions back to the user for approval. Thin by design — this skill routes, it does not do the work itself."
---

# Project Orchestrator

## Purpose

Be the agent that notices what time it is, what state the project is in, and what the sensible next action is. The orchestrator reads; other skills act. On any given day, invoking `project-orchestrator` produces a prioritized list of "what you (or I) should do now" rooted in the state and calendar, not a fixed routine.

It is thin. It knows the *rhythm* of a grant project; the details live in the other skills.

## Trigger phrases

- "what should I do today / this week"
- "run the project" / "run the orchestrator"
- "morning briefing" / "daily briefing"
- "what's pending" / "what needs attention" / "what's on deck"
- "are there any deadlines coming up"
- "kickoff the day" / "kickoff the week"
- "run the weekly routine"

## The cadence model

Grant projects run on overlapping clocks:

| Clock        | Events                                                       |
| ------------ | ------------------------------------------------------------ |
| Daily        | (optional) standup, inbox check, at-risk milestone review    |
| Weekly       | Monday weekly report; at-risk escalation; mid-week milestone check-ins |
| Monthly      | Monthly technical brief (best practice per PIC PM Guide)     |
| Quarterly    | SC meeting; claim submission (20th of Apr/Jul/Oct/Jan); financial reporting |
| Annual       | PIC Annual Questionnaire; annual risk assessment; financial update |
| Phase        | Gate polling; transition readiness; kickoff/closeout rhythms |
| Event-driven | MPA signature; milestone completion; Change Order raised; IP disclosure; publication proposal; risk materialization |

The orchestrator knows roughly when each clock ticks and offers the right next action.

## The decision loop

On invocation:

1. **Load state.** Get current phase, health, recent activity, pointers (last_weekly_report, last_sc_meeting, last_claim_submitted, next_claim_due, next_sc_meeting).
2. **Compute windows.**
   - Days since last weekly report. If ≥7, flag "weekly due".
   - Days to next claim due date (Apr/Jul/Oct/Jan 20). If ≤14, flag "claim due soon". If ≤3, flag "claim due URGENT".
   - Days to next SC meeting. If ≤14, flag "SC pack prep". If ≤7, flag "SC pack due".
   - Days to annual questionnaire (if set).
3. **Check at-risk milestones.** Via `project-milestone-manager`. Any with `status in {at_risk, blocked}` or behind-schedule rules get flagged.
4. **Check gate.** Via `project-phase-gate`. If the current phase has unblocked items (e.g., MPA landed → planning.mpa_signed autoclose), surface the transition option.
5. **Check inbox.** If `documents/inbox/` is non-empty, flag "classify N new docs".
6. **Compose enabled capabilities' routines.** See "Capability routines" below.
7. **Prioritize.** Order: URGENT deadlines → gate-blocking items → pending reports → at-risk milestones → routine work → opportunities. Capability items rank by their declared `severity` alongside core items — they are not a separate section and never get their own digest.
8. **Return a ranked list** with, for each item: the reason, the skill that handles it, and what the user needs to do.

## Output format

```
# Orchestrator — YYYY-MM-DD

## 🔴 Urgent
- <items that cannot wait>

## 🟡 This week
- <items due in 7 days>

## 🟢 On deck
- <items on the weekly horizon>

## 💤 Quiet
- <nothing to flag here>

---
What would you like to do first?
```

Every line links to the skill that handles it, so the user can say "yes, do the weekly report" and the orchestrator delegates to `project-status-reporter`.

## Capability routines

A capability plugin (`sred`, `tender-intelligence`) knows a rhythm the core orchestrator does not.
Rather than shipping its own orchestrator — which would duplicate this calendar logic and give the
operator two competing answers to "what should I do today" — a capability ships
`capabilities/<id>/routine.yaml`, and this skill composes it.

**Step 6 of the decision loop:**

1. Read `manifest.yaml → capabilities`. For each entry with `enabled: true`, load
   `capabilities/<id>/routine.yaml`. A capability that is disabled, or has no routine file,
   contributes nothing — skip it silently.
2. Read the capability's runtime state (`routine.state.runtime`, e.g. `state/sred.json`) once.
3. Evaluate each `checks[]` entry's `when:` condition against that state and the substrate.
   A check whose condition does not hold produces nothing. Conditions are read-only — evaluating
   the routine must never write.
4. Emit each firing check as a digest item at its declared `severity`
   (`urgent` → 🔴, `soon` → 🟡, `ondeck` → 🟢), interpolating `{...}` placeholders from state,
   carrying its `action:` and its `handler:` skill.
5. If the routine declares `always_surface:`, render it as standing context at the top of the
   digest whenever its `suppress_when:` does not hold. This exists for hard external deadlines —
   an SR&ED filing window is unforgiving and must be visible on a day when nothing else fires.
6. If no check fired and `quiet_when:` holds, report `quiet_message` under 💤. **Do not
   manufacture an item.** A capability with nothing to say is a healthy result, and inventing
   busywork to fill the section trains the operator to skip the digest.

**Ordering discipline.** Capability items interleave with core items by severity. A 🔴 SR&ED
deadline outranks a 🟡 weekly report; a 🟢 SR&ED quarterly nudge sits below an at-risk milestone.
The operator reads one prioritized list, not a core list plus per-capability appendices.

**Scheduling is not here.** Capability *scheduling* lives in the reporting matrix, seeded from the
capability's bundled pack at enable and compiled by `project-automator` into
`automation/tasks.yaml` — the `tick` routine below dispatches it like any other entry, and the
generic `deadline` cadence already handles per-capability escalation tiers via
`state/<capability>.json:escalation_tiers_fired`. `routine.yaml` answers the *conversational*
question ("what does this capability want looked at right now"), which the tick does not.

## Routines

The orchestrator understands named routines:

### `tick` — the registry-driven scheduler

The single routine that makes reporting *automatic*. It is deterministic: read the
cadence registry, compute what is due today, dispatch the generators. Each generator
self-queues its draft into `outbox/queue/` (see each skill's "Outbox emission"),
so a tick's whole job is **decide what's due and call the right generator** — it
authors nothing and sends nothing.

**Algorithm:**

1. Read `project-state/automation/tasks.yaml` (`tasks[]`) — the **canonical cadence
   registry** (`project-automator` compiles it from the matrix; the kanban calendar
   writes operator reschedules into it, so it always carries the live schedule).
   Resolve each task's target: `kind: matrix` → the matching `reporting-matrix.yaml`
   entry (generator, profile, surface; the matrix `enabled` flag is authoritative for
   matrix tasks); `kind: action` → the named skill action; `kind: adhoc` → the task's
   own stored prompt. Skip disabled tasks and `status: proposed` tasks (unaccepted
   ghost holds never fire). **Fallback:** only if `automation/tasks.yaml` does not
   exist, read `reporting-matrix.yaml` entries directly (skipping `enabled: false`)
   as in v2.0.
2. For each remaining task, evaluate its `cadence` against today's date and the relevant
   `state.json:pointers` (e.g. `last_weekly_report`):
   - `weekly` (`day: <dow>`) → due if today is that weekday **and** no run is
     recorded since the start of this week.
   - `monthly` → due on the configured day / last working day, once per month.
   - `quarterly` / deadline-bound (`Apr/Jul/Oct/Jan`) → due when today falls inside
     the entry's `lead_time` window before the deadline (default 14 days).
   - `sprint-aligned` → due on the sprint boundary from the active sprint calendar.
   - `deadline` → due when today ≥ (`due` − `lead_days`), once per period (the task's `fy`).
     **Independently of dueness**, compare today against each `escalation` tier relative to
     the `hard` date; on first crossing (check `state/<capability>.json:escalation_tiers_fired`),
     emit `<capability>.deadline.warning|alert|critical` and place the item in 🔴
     (critical/alert) or 🟡 (warning). A task past its `hard` date with non-terminal status
     is a permanent 🔴 ("claim window forfeited unless filed") until a human records the
     terminal status. **Chaining:** a task with `after:` dispatches only once the referenced
     entry has a completed run for the same period; `review_gate:` additionally requires a
     completion event from the named skill with a verdict in `pass_on`. Chains evaluate
     within a single tick pass; unsatisfied chains show in the digest as "waiting on <entry>".
   - `event-driven` / `on-publish` → **never** time-due; these fire from activity-log
     triggers (`phase-transition`, `milestone-completion`, `documents/published/`),
     not from the tick. Skip them here.
3. Build the **due-list**: `[ {entry-id, generator, profile?, reason} ]`.
4. For each due entry, invoke its `generator` (passing `profile` if present). The
   generator produces its report **and** drops an outbox card.
5. Surface the result to the user as the standard digest (🔴/🟡/🟢) noting which
   cards were just queued: "Queued 2 drafts for review → /queue."
6. Append one `orchestrator.tick` event per dispatch to the activity log so the
   Schedule view can show last-run.

**Discipline for the tick:** it dispatches generators, never sends. If nothing is
due, say so — a tick with an empty due-list is a healthy quiet day. Idempotent:
re-running a tick on the same day must not double-queue (the per-period pointer /
"already run this week" check prevents duplicates).

**Dry run:** `tick --dry-run` prints the due-list without invoking generators —
use it to preview what a scheduled run would do.

### `daily` (optional — only if the team wants a daily check)
1. **Run `project-harvester`** — pull fresh intel from Slack/Gmail/GDocs/scsiwyg into `documents/inbox/`. Run before anything else so the inbox is populated before curator recommendations are made.
2. **Run `project-document-curator`** — classify any new inbox docs; link to milestones/decisions where appropriate.
3. Tail activity log since yesterday
4. Check `at_risk` and `blocked` milestones
5. Flag any unclassified docs remaining in inbox
6. Report any Gmail drafts from yesterday not yet sent (if integrated)
7. **Suggest `project-git checkpoint`** if `git status --short` shows uncommitted changes — mention it at the end of the daily summary: "You have uncommitted changes. Run `project-git checkpoint` to record today's work."

### `end-of-session`
When the user signals end of day, end of session, or "wrapping up":
1. Tail activity log for events since last commit.
2. If uncommitted changes exist, propose a checkpoint: surface the auto-generated commit message and ask "Ready to checkpoint?" Do not commit automatically.
3. If the next SC meeting or claim deadline is within 7 days, flag it as a reminder.
4. Remind the user to push if working with a team: "After checkpointing, run `project-git push` to share with teammates."

### `weekly` (Monday)
1. Call `project-status-reporter` to draft the weekly report
2. Hand off to `project-notifier` to post to Slack after the user reviews
3. Check SC prep window (meeting in <14 days?) → start SC pack prep
4. Check claim window (claim in <14 days?) → start claim prep
5. Recompute `state.json:health`
6. Update `state.json:pointers.last_weekly_report`

### `monthly` (last working day of month)
- Monthly technical brief to consortium (`project-status-reporter` monthly mode)
- Review + refresh risk register
- Nudge IP disclosure review

### `quarter-close` (around the 15th of Apr/Jul/Oct/Jan)
- Call `project-funder-reporting` to assemble the quarterly claim
- Draft the PIC PM cover email via `project-notifier` (Gmail draft)
- Nudge Finance Rep for member claim packages
- Schedule the SC meeting if one is due

### `sc-prep` (10 business days before a SC meeting)
- Call `project-review-meeting` to build agenda + pack
- Invite check via `project-notifier`
- Circulate agenda 5+ business days prior

### `baseline` (on phase transition, milestone completion, or on demand)
- Call `project-doc-suite-generator` to produce the baseline report bundle
- Output: `project-state/reports/baseline/Baseline-Reports-YYYY-MM-DD/` with styled `.docx` + `.xlsx`
- Copy to website `public/downloads/baseline/` for static serving
- Log `report.generated` event to activity log

### `phase-check` (weekly during planning and closeout, monthly during execution)
- Call `project-phase-gate` for gate status
- If ready-to-transition, surface the prompt; then trigger the `baseline` routine

## Scheduling

The orchestrator does not run itself. It is invoked:
- On user demand ("what should I do?")
- By the `schedule` skill (a scheduled task calls `project-orchestrator daily` each morning)
- By a cron firing **`project-orchestrator tick`** on the registry's natural cadence
  (e.g. early each weekday). The cron is a thin trigger; all scheduling *logic* lives
  in the `tick` routine reading `automation/tasks.yaml` (falling back to
  `reporting-matrix.yaml` when no registry exists), so the schedule is testable
  and inspectable in the substrate rather than buried in cron config. The kanban
  **Calendar view** (`/calendar`) renders the same registry with computed next-due and
  last-run so a human can see what the next tick will do.

`project-state/manifest.yaml` does not specify schedules; those are managed via the `schedule` skill and should be configured separately.

**Registering the cron from the UI.** The kanban **Schedule view** (`/schedule`) now
manages the recurring trigger directly: an Automation panel registers / pauses /
removes a single marked block in the user's crontab that runs `project-orchestrator
tick` on a chosen cadence (weekday-mornings preset, etc.). The cron command runs
`claude -p` headless with `--permission-mode bypassPermissions --max-budget-usd 2`,
logging to `logs/cron-tick.log`. The human clicks **Register** — the app does not
register it silently. The Schedule view's "Last tick" reflects real runs once active.

## Discipline

- **Don't do the work, delegate it.** This skill returns recommendations + invokes other skills; it doesn't draft reports, file claims, or send emails itself.
- **Don't surprise the user.** Even when a next step is obvious, offer it — don't execute. Especially for anything going to PIC.
- **Honor the quiet days.** If there's genuinely nothing to do, say so. A healthy project has quiet days.
- **Respect phase.** In planning, focus on gate items. In execution, focus on rhythm. In closeout, focus on final reports. The orchestrator's priorities shift by phase.

## Integration

Calls every other skill in the suite, including `project-doc-suite-generator` for baseline report bundles. Does not read or write state directly — goes through `project-state`. Its output is often consumed by the user verbally, but it may also write an orchestrator-run snapshot to `reports/adhoc/orchestrator-YYYY-MM-DD.md` for audit.

- **project-git** — suggested at end of daily routine and end-of-session; the orchestrator surfaces the checkpoint prompt but never calls `git commit` automatically.

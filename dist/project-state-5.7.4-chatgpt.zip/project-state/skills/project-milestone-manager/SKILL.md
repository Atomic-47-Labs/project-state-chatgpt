---
name: project-milestone-manager
description: "Create or update milestones — 'update M03', 'M02 is 60% done', 'mark M01 complete', 'what's at risk', 'the event moved'. Progress narratives accumulate; re-anchors seeded plans when dates slip."
metadata:
  map:
    tier: P1
    stage: keep
    requires: [memory]
    binding: mcp-ready
    reads: [milestones]
    writes: [milestones, reports, log]
---

# Project Milestone Manager

> **When to use — full trigger description.** The frontmatter carries a short, trigger-first
> description so all of the suite's skills fit Claude Code's skill-listing budget (see
> docs/SKILL-SPEC.md, *Description budget*). The complete version, kept here:
>
> CRUD project milestones, update percent complete and technical progress narrative, flag at-risk or blocked milestones, and regenerate the tracking xlsx from the YAML source of truth. Use this skill whenever the user says 'update M03', 'milestone status', 'how's M05 going', 'mark M01 complete', 'what milestones are at risk', 'recompute overall percent complete', 'list milestones', 'add a new deliverable to M07', 'assign owner to M12', 'regenerate the milestones tracker', 'the event moved', 'the launch slipped', or any request to read or write milestone state. Also trigger when project-status-reporter needs milestone data for a weekly report or SC pack, when project-funder-reporting needs % complete + technical_progress for the quarterly claim, when project-phase-gate checks whether gate milestones are done, or when project-change-register needs to know which milestones a change affects. PIC requires technical_progress + percent_complete per milestone on every claim — this skill owns that surface.

## Purpose

Milestones are the spine of every project — a campaign's launch beats, an event's countdown, a
release plan, a grant's Schedule A. Status reports, review meetings and (on a funded project) claims
all report against them. This skill is the single interface for everything milestone-related.

On a PIC-funded project the Master Project Agreement's Schedule A lists them, quarterly claims report
progress against them and Steering Committee meetings review them. Per PIC PM Guide, the two fields that *must* be reported on every milestone every quarter are:
- `percent_complete` — integer 0–100
- `technical_progress` — narrative string describing what was accomplished

Every other field (planned/actual dates, deliverables, owner, budget category, status, at-risk reason) supports those two.

## Trigger phrases (priority order)

1. "update M03" / "update milestone M03"
2. "mark M01 complete" / "M05 is done"
3. "what milestones are at risk?"
4. "list milestones" / "show me the milestone status"
5. "how's M05 going?"
6. "assign owner to M12" / "M07's owner is Jane"
7. "add a deliverable to M04"
8. "recompute overall percent complete" / "project health"
9. "regenerate the milestones tracker" / "rebuild tracking/milestones.xlsx"
10. "the event moved to 9 April" / "the launch slipped two weeks" / "push the plan back" → `reanchor()`
11. Any `project-*` skill fetching milestone data

## Operations

**Which home.** If a project-state MCP is connected (the Project State connector, or the local one the
plugin ships; its tools include `project_list`, `get_entity` and `entity_patch`), call `project_list` first. If it
lists this project, with `home: server` or `home: local` alike (the local server writes the folder for you;
`local` is not a cue to edit files), every read and write goes through those tools, the activity-log entry included: after
an `entity_put` / `entity_patch` / `entity_delete`, append the skill's event with `log_append` (the screen
actions, such as `milestone_update`, log their own). Work on the files directly only when no MCP serves the
project.

Every read and write goes through the memory layer (`project-state`), which names entities by **kind
and id**, never by path: a milestone is kind `milestone` with an id like `M03-matrix-editor`. On disk,
`project-state`'s kinds reference says where each kind lives; over the Project State connector, pass the
kind and id (or use `milestone_update` for status and percent complete) and the server places it. The
same steps work in both homes.

### `list_milestones(filter?)`

Read every milestone entity (kind `milestone`; over the connector, `list_entities` or `view_board`). Return an array sorted by id. Optional filters:
- `status: planned | in_progress | at_risk | complete | blocked` — `blocked` renders in the **At Risk** column in the kanban
- `owner_short: "OrgA" | "OrgB"`
- `proposal_phase: "Phase 1 – ..."` (loose match)
- `at_risk: true` (shortcut for status in {at_risk, blocked})

Output fields: `id, title, owner_short, planned_start, planned_end, percent_complete, status, at_risk_reason`.

### `get_milestone(id)`

Read one milestone file and return the full parsed YAML.

### `create_milestone(...)`

Rarely needed — we seeded 13 at scaffold. Use when Schedule A is amended via Change Order to add a milestone. Require:
- `id` (Mxx format, next available)
- `title`
- `owner_org`, `owner_short`
- `description`
- `planned_start`, `planned_end`
- `completion_criteria`
- `mpa_reference` — reference to Schedule A position

Filename: `M<NN>-<kebab-slug>.yaml` where `<NN>` matches the MPA Schedule A number.

### `update_milestone(id, fields)`

The most-used operation. Common field updates:

| User says                              | Fields updated                                          |
| -------------------------------------- | ------------------------------------------------------- |
| "M03 is 40% done, pilot batches 5-10 complete" | `percent_complete: 40`, and **append** to `technical_progress`: `"2026-09-07: Pilot batches 5-10 complete; batches 1-4 pending rework on sensor calibration."` |
| "M05 is at risk — waiting on M04 data" | `status: at_risk`, `at_risk_reason: "Blocked on M04 labeled dataset completeness."` |
| "M01 is done"                          | `status: complete`, `percent_complete: 100`, `actual_end: <today>` |
| "M07 started today"                    | `status: in_progress`, `actual_start: <today>`          |
| "Jane from OrgB now owns M11"          | `owner_person: <slug-of-person-record>` (create people entry if missing via project-state) |

**`technical_progress` accumulates — never overwrite it.** It is the milestone's running narrative;
funder claims, SC packs and status reports quote it, and a claim period needs to see what was already
reported. Keep every existing line and add the new progress as a dated line (`YYYY-MM-DD: …`) at the
end. Restate nothing that is already there, and never condense earlier entries into a summary. To
correct an earlier line, add a dated correction rather than editing it — the same rule as the
activity log.

All writes go through `project-state` for locking + logging. Event names:
- `milestone.created`
- `milestone.updated` (default)
- `milestone.completed` (when `status: complete` set)

### `check_at_risk()`

Surface milestones that need attention. Rules:
- `status in {at_risk, blocked}` → always
- `status == in_progress AND planned_end - today < 14 days AND percent_complete < 70` → "behind schedule"
- `status == planned AND planned_start < today` → "late start"
- Any milestone with stale `technical_progress` (not updated in 30 days) while `status == in_progress` → "stale progress"

Return a prioritized list with reasons and suggested actions.

### `compute_overall_progress()`

Return:
- Weighted overall % complete (weight each milestone equally unless budget weights are available from Schedule A)
- Count by status
- Count by owner org
- Count by proposal phase
- "On-track?" — green if all `in_progress` milestones are on or ahead of schedule; yellow if any behind; red if any blocked

Store the result as the `health` field of the state record (kind `state`) via `project-state`, which logs `health.assessed`.

#### `overall_percent` is all-time, and now says so

`overall_percent` is a mean over **every milestone ever declared**, which is the right number for a
project with one ending and a misleading one for a facility that keeps going. Six complete milestones
read 100; adding a seventh for the next increment reads 85. But 85 of *what*? The number has quietly
stopped meaning "how much of this project is done" and started meaning "how much of everything ever
conceived is done". After several increments a facility that ships perfectly every time converges on
100 and never once reports that the increment in front of it is finished.

Two changes, both additive:

- **Always write `health.scope: "all-time"`.** `overall_percent` keeps its exact computation and its
  exact meaning — the existing consumers of the rollup read the same field and get the same value.
  What changes is that the field now states what it measures. This is disclosure, not a fix, and spec
  §5.3 says so plainly.
- **When the state record's `lifecycle` is `continuous`, also write `health.increment`,** scoped to
  `current_increment`: `{id, percent, milestones_total, by_status}`. Membership is
  `milestone.increment == current_increment`, else the increment manifest's `milestones` list. This is
  the number that answers *are we done with what we are doing now.*

Never write `health.increment` on a terminal facility — its absence is how a reader knows there is only
one pass.

Also report `milestones_total` as a count of **unique** ids. A facility with two files claiming the
same id (this repo's own facility has two `M10`s) otherwise makes `counters.milestones` and
`milestones_total` disagree with nothing explaining why. `project-state`'s validator reports the
collision; this operation must not paper over it.

#### Which number to show

Readers prefer `health.increment.percent` where present and fall back to `overall_percent`. When
reporting to a human on a continuous facility, lead with the increment number and name the increment:
*"v1.1 is 40% complete (all-time across 45 milestones: 6%)."* A bare percentage on a continuous
facility is ambiguous, and that ambiguity is the defect.

Deprecating `overall_percent` in favour of a scoped-by-default rollup is a v5 conversation — spec §9,
open question 1 — not something this operation decides.

#### `increment` on a milestone

Optional. Absent on every existing milestone and never backfilled. A milestone with no `increment` on a
continuous facility counts toward `overall_percent` and not toward `health.increment` unless the
increment manifest lists it — the conservative reading: unassigned work is real work, but it is not
evidence that *this* increment is done.

### `regenerate_tracker()`

Build/refresh `tracking/milestones.xlsx` from the YAML source:
- One row per milestone
- Columns: id, title, owner_org, proposal_phase, planned_start, planned_end, actual_start, actual_end, percent_complete, status, at_risk_reason, technical_progress, completion_criteria
- Add a conditional-format traffic-light column based on `check_at_risk()` output
- Second sheet: summary (count by status, owner, phase; overall %)

Use the `xlsx` skill for the heavy lifting; do not write xlsx from scratch. The xlsx is a *view* — the YAML remains source of truth.

Event logged: `tracking.regenerated` with `target: "milestones.xlsx"`.

### `reanchor()`

When a date the plan hangs off moves — `phases.anchor_date` (event day, launch day),
`project.start_date` or `project.end_date` — first write the new date to the manifest through
`project-state`, then move the milestones that were seeded from it:

```bash
python3 <project-scaffolder>/scripts/seed_pack.py reanchor --state project-state --dry-run
python3 <project-scaffolder>/scripts/seed_pack.py reanchor --state project-state --actor <operator email>
```

This runs a script over a working copy, so it is available where the project's files are (the file binding,
or the server runner); over the connector in claude.ai, list the milestones that would move and change them
one by one with `milestone_update` / `entity_patch` instead. Show the dry run and get a yes before the real run. It moves only milestones that carry `seed_due`
(adopted from a pack seed) **and** whose `planned_end` still equals what that expression gave against
the dates recorded in `seed_basis`. A milestone someone re-dated by hand, a completed one, and any
milestone that was never seeded are left exactly as they are and listed as *kept*, so the operator can
decide about those one by one. Edits are line-level — comments and field order survive. Each move logs
`milestone.updated`; the run logs `milestones.reanchored`.

Anchored reporting deadlines (a run-of-show brief at `anchor-7d`) need nothing: the kanban scheduler
recomputes them from the current anchor on every tick.

A move of three months or more is still a material change — hand it to `project-change-register`.

## Discipline rules

- **Never silently accept a 0%→100% jump without a completion event.** If `percent_complete` is set to 100, `status` must become `complete` and `actual_end` must be set.
- **Never let `percent_complete` go backward.** If an update would decrease it, require an explicit user confirmation and append a note to `technical_progress` explaining the regression.
- **Always update `technical_progress` when `percent_complete` changes.** If the user provides a number but no narrative, ask them for one line of context. PIC requires the narrative.
- **Require `at_risk_reason` when `status` becomes `at_risk` or `blocked`.**
- **Don't edit `completion_criteria` casually.** That text is from the MPA Schedule A. Edits to it require a Change Order.
- **Respect ownership.** If asked to update a milestone owned by a different organisation, warn and suggest confirming with the owner before making changes.

## Integration with other skills

- **project-state** — all writes route through it.
- **project-status-reporter** — pulls milestone state for weekly reports, SC packs, and quarterly claims.
- **project-funder-reporting** — pulls `percent_complete` + `technical_progress` per milestone at quarter-close for the PIC MS & financial tracking form.
- **project-phase-gate** — may reference milestone completion as a gate-out criterion (e.g., M13 complete → closeout gate opens).
- **project-change-register** — when a milestone is added/subtracted or its timeline shifts ≥3 months, that's a material change requiring a Change Order.

## Worked example

**User:** "Mark M01 as 60% complete — we got the first year of historical data loaded and the baseline cycle time and yield validated. Still waiting on the two energy-consumption datasets."

**Skill:**
1. Read the milestone `M01-cdi-data-readiness`.
2. Update:
   - `percent_complete: 60`
   - `technical_progress: "Year 1 historical data loaded and integrated. Baseline cycle time and yield KPIs validated and approved. Remaining: Year 2/Year 3 energy consumption datasets expected by 2026-04-25."`
   - `last_modified: <now>`, `last_modified_by: <user>`
3. Call project-state to acquire lock, write, release, log `milestone.updated` with summary.
4. Run `check_at_risk()` — M01 is 60% with 7 days to planned_end; returns "behind schedule" (60% with only 14 days to reach 100% is tight but achievable).
5. Offer to also update the tracking xlsx.
6. Return updated entity + at-risk status.

## Reference files

- `references/milestones-ownership.md` — who owns what (seeded from proposal)
- `references/claim-mapping.md` — how milestone % and technical_progress map to the PIC MS & financial tracking form fields
